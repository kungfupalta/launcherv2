# Ultra Launcher

Launcher para Android (Kotlin + Jetpack Compose) con estética One UI del Samsung Galaxy S26 Ultra.

- Inicio con fondo de pantalla del sistema, reloj grande y fecha.
- **Línea pequeña debajo de la hora**: "Hora de Marcos · Argentina" u "Hora de Arianna · Ecuador". Tocala para elegir cuál mostrar (se guarda).
- Páginas con indicador de puntos, dock translúcido de 4 apps, iconos squircle.
- Deslizar hacia arriba: cajón de apps con buscador. Deslizar hacia abajo: notificaciones.
- Mantener pulsado un icono: menú (quitar / añadir a inicio / info / desinstalar).
- Mantener pulsado un espacio vacío: fondos de pantalla, elegir hora y ajustes.

Se compila con GitHub Actions (ver `.github/workflows/build.yml` en el repo).
