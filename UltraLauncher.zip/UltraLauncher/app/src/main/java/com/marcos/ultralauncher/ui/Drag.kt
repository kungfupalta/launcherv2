package com.marcos.ultralauncher.ui

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import com.marcos.ultralauncher.AppInfo

enum class DragSource { HOME, DOCK }

/**
 * Estado del arrastre de un icono (inicio o dock). Las posiciones están en coordenadas de la raíz.
 * Los huecos se identifican como "h:<clave>" (inicio) o "d:<clave>" (dock).
 */
@Stable
class DragController {
    var app by mutableStateOf<AppInfo?>(null)
        private set
    var source by mutableStateOf(DragSource.HOME)
        private set
    var pointer by mutableStateOf(Offset.Zero)
        private set
    var overTrash by mutableStateOf(false)
        private set
    var targetSlot by mutableStateOf<String?>(null)
        private set

    var startPointer: Offset = Offset.Zero
        private set

    val active: Boolean get() = app != null

    val rects = HashMap<String, Rect>()
    var trashRect: Rect = Rect.Zero
    var gridRect: Rect = Rect.Zero
    var dockRect: Rect = Rect.Zero

    private var selfSlot: String = ""

    fun begin(app: AppInfo, source: DragSource, slot: String, at: Offset) {
        this.app = app
        this.source = source
        this.selfSlot = slot
        this.startPointer = at
        update(at)
    }

    fun update(p: Offset) {
        pointer = p
        overTrash = trashRect.contains(p)
        targetSlot = if (overTrash) {
            null
        } else {
            rects.entries.firstOrNull { it.key != selfSlot && it.value.contains(p) }?.key
        }
    }

    fun cancel() {
        app = null
        overTrash = false
        targetSlot = null
        selfSlot = ""
    }
}
