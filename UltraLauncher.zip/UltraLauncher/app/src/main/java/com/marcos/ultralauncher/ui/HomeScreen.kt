package com.marcos.ultralauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.marcos.ultralauncher.AppInfo
import com.marcos.ultralauncher.ClockPerson

private const val COLUMNS = 4
private const val DOCK_SLOTS = 4

private fun paginate(items: List<AppInfo>, firstPage: Int, otherPages: Int): List<List<AppInfo>> {
    if (items.isEmpty()) return listOf(emptyList())
    val pages = mutableListOf<List<AppInfo>>()
    var index = 0
    var size = firstPage
    while (index < items.size) {
        val end = minOf(index + size, items.size)
        pages.add(items.subList(index, end))
        index = end
        size = otherPages
    }
    return pages
}

@Composable
fun HomeScreen(
    homeApps: List<AppInfo>,
    dockApps: List<AppInfo>,
    person: ClockPerson,
    homeSignal: Int,
    onPersonSelected: (ClockPerson) -> Unit,
    onOpen: (AppInfo) -> Unit,
    onRemoveFromHome: (AppInfo) -> Unit,
    onRemoveFromDock: (AppInfo) -> Unit,
    onInfo: (AppInfo) -> Unit,
    onUninstall: (AppInfo) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.fillMaxSize()) {

        BoxWithConstraints(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .statusBarsPadding(),
        ) {
            val cellHeight = 96.dp
            val clockHeight = 200.dp
            val indicatorSpace = 26.dp

            val rowsFirst = ((maxHeight - clockHeight - indicatorSpace) / cellHeight).toInt().coerceAtLeast(1)
            val rowsOther = ((maxHeight - indicatorSpace) / cellHeight).toInt().coerceAtLeast(1)

            val pages = remember(homeApps, rowsFirst, rowsOther) {
                paginate(homeApps, COLUMNS * rowsFirst, COLUMNS * rowsOther)
            }
            val pageCount = pages.size
            val pagerState = rememberPagerState(pageCount = { pageCount })

            LaunchedEffect(homeSignal) {
                if (homeSignal > 0) pagerState.animateScrollToPage(0)
            }

            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
            ) { page ->
                Column(Modifier.fillMaxSize()) {
                    if (page == 0) {
                        ClockWidget(
                            person = person,
                            onPersonSelected = onPersonSelected,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(clockHeight)
                                .padding(horizontal = 28.dp, vertical = 20.dp),
                        )
                    }
                    IconGrid(
                        apps = pages.getOrElse(page) { emptyList() },
                        cellHeight = cellHeight,
                        onOpen = onOpen,
                        onRemove = onRemoveFromHome,
                        onInfo = onInfo,
                        onUninstall = onUninstall,
                    )
                }
            }

            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(7.dp),
            ) {
                repeat(pageCount) { i ->
                    val selected = i == pagerState.currentPage
                    Box(
                        Modifier
                            .size(if (selected) 7.dp else 6.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = if (selected) 1f else 0.45f)),
                    )
                }
            }
        }

        // Dock
        Box(
            modifier = Modifier
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(32.dp))
                    .background(Color.White.copy(alpha = 0.16f))
                    .padding(horizontal = 6.dp, vertical = 10.dp),
            ) {
                dockApps.take(DOCK_SLOTS).forEach { app ->
                    AppIcon(
                        app = app,
                        showLabel = false,
                        onClick = { onOpen(app) },
                        menu = listOf(
                            MenuAction("Quitar del dock") { onRemoveFromDock(app) },
                            MenuAction("Info de la app") { onInfo(app) },
                            MenuAction("Desinstalar") { onUninstall(app) },
                        ),
                        modifier = Modifier.weight(1f),
                    )
                }
                repeat(DOCK_SLOTS - dockApps.size.coerceAtMost(DOCK_SLOTS)) {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun IconGrid(
    apps: List<AppInfo>,
    cellHeight: Dp,
    onOpen: (AppInfo) -> Unit,
    onRemove: (AppInfo) -> Unit,
    onInfo: (AppInfo) -> Unit,
    onUninstall: (AppInfo) -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp),
    ) {
        apps.chunked(COLUMNS).forEach { row ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(cellHeight),
            ) {
                row.forEach { app ->
                    AppIcon(
                        app = app,
                        showLabel = true,
                        onClick = { onOpen(app) },
                        menu = listOf(
                            MenuAction("Quitar de inicio") { onRemove(app) },
                            MenuAction("Info de la app") { onInfo(app) },
                            MenuAction("Desinstalar") { onUninstall(app) },
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                    )
                }
                repeat(COLUMNS - row.size) {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}
