package com.marcos.ultralauncher.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.marcos.ultralauncher.AppInfo
import com.marcos.ultralauncher.ClockPerson
import com.marcos.ultralauncher.UiSettings
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private const val DOCK_SLOTS = 4

private fun paginate(items: List<AppInfo>, firstPage: Int, otherPages: Int): List<List<AppInfo>> {
    if (items.isEmpty()) return listOf(emptyList())
    val pages = mutableListOf<List<AppInfo>>()
    var index = 0
    var size = firstPage
    while (index < items.size) {
        val end = minOf(index + size, items.size)
        pages.add(items.subList(index, end))
        index = end
        size = otherPages
    }
    return pages
}

private class PageHolder {
    var items: List<AppInfo> = emptyList()
}

@Composable
fun HomeScreen(
    homeApps: List<AppInfo>,
    dockApps: List<AppInfo>,
    person: ClockPerson,
    homeSignal: Int,
    settings: UiSettings,
    onPersonSelected: (ClockPerson) -> Unit,
    onOpen: (AppInfo) -> Unit,
    onRemoveFromHome: (AppInfo) -> Unit,
    onRemoveFromDock: (AppInfo) -> Unit,
    onInfo: (AppInfo) -> Unit,
    onUninstall: (AppInfo) -> Unit,
    onMoveHome: (String, String) -> Unit,
    onMoveDock: (String, String) -> Unit,
    onHomeToDock: (String, String?) -> Unit,
    onDockToHome: (String, String?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val drag = remember { DragController() }
    val pageHolder = remember { PageHolder() }
    var origin by remember { mutableStateOf(Offset.Zero) }

    val shape = settings.shape.toShape()
    val columns = settings.columns
    val iconDp = settings.iconDp.dp
    val showLabels = settings.showLabels
    val cellHeight = if (showLabels) iconDp + 40.dp else iconDp + 26.dp

    // Se llama al soltar el icono: decide si va a la papelera, a otro hueco o vuelve a su sitio.
    fun finishDrag() {
        val app = drag.app
        if (app != null) {
            val src = drag.source
            val target = drag.targetSlot
            val targetKey = target?.drop(2)
            val onHomeCell = target?.startsWith("h:") == true
            val onDockCell = target?.startsWith("d:") == true
            val p = drag.pointer
            when {
                drag.overTrash -> {
                    if (src == DragSource.HOME) onRemoveFromHome(app) else onRemoveFromDock(app)
                }
                src == DragSource.HOME && onHomeCell && targetKey != null -> onMoveHome(app.key, targetKey)
                src == DragSource.HOME && onDockCell && targetKey != null -> onHomeToDock(app.key, targetKey)
                src == DragSource.DOCK && onDockCell && targetKey != null -> onMoveDock(app.key, targetKey)
                src == DragSource.DOCK && onHomeCell && targetKey != null -> onDockToHome(app.key, targetKey)
                src == DragSource.HOME && drag.dockRect.contains(p) -> onHomeToDock(app.key, null)
                src == DragSource.HOME && drag.gridRect.contains(p) -> {
                    val last = pageHolder.items.lastOrNull { it.key != app.key }
                    if (last != null) onMoveHome(app.key, last.key)
                }
                src == DragSource.DOCK && drag.gridRect.contains(p) -> onDockToHome(app.key, null)
            }
        }
        drag.cancel()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .onGloballyPositioned { origin = it.positionInRoot() },
    ) {
        Column(Modifier.fillMaxSize()) {

            BoxWithConstraints(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .onGloballyPositioned { drag.gridRect = it.boundsInRoot() },
            ) {
                val clockHeight = 200.dp
                val clockSpace = if (settings.showClock) clockHeight else 0.dp
                val indicatorSpace = 26.dp

                val rowsFirst = ((maxHeight - clockSpace - indicatorSpace) / cellHeight).toInt().coerceAtLeast(1)
                val rowsOther = ((maxHeight - indicatorSpace) / cellHeight).toInt().coerceAtLeast(1)
                val perFirst = columns * rowsFirst
                val perOther = columns * rowsOther

                val pages = remember(homeApps, perFirst, perOther) {
                    paginate(homeApps, perFirst, perOther)
                }
                val pageCount = pages.size
                val pagerState = rememberPagerState(pageCount = { pageCount })
                pageHolder.items = pages.getOrElse(pagerState.currentPage) { emptyList() }

                LaunchedEffect(homeSignal) {
                    if (homeSignal > 0) pagerState.animateScrollToPage(0)
                }

                // Arrastrando un icono hacia el borde izquierdo/derecho cambia de página.
                val edgePx = with(density) { 40.dp.toPx() }
                val widthPx = with(density) { maxWidth.toPx() }
                val edgeDir by remember(edgePx, widthPx) {
                    derivedStateOf {
                        when {
                            !drag.active || drag.source != DragSource.HOME -> 0
                            drag.pointer.x < edgePx -> -1
                            drag.pointer.x > widthPx - edgePx -> 1
                            else -> 0
                        }
                    }
                }
                LaunchedEffect(edgeDir) {
                    if (edgeDir != 0) {
                        while (true) {
                            delay(650)
                            val target = pagerState.currentPage + edgeDir
                            if (target in 0 until pagerState.pageCount) {
                                pagerState.animateScrollToPage(target)
                            }
                        }
                    }
                }

                HorizontalPager(
                    state = pagerState,
                    beyondViewportPageCount = (pageCount - 1).coerceAtLeast(0),
                    modifier = Modifier.fillMaxSize(),
                ) { page ->
                    Column(Modifier.fillMaxSize()) {
                        if (page == 0 && settings.showClock) {
                            ClockWidget(
                                person = person,
                                onPersonSelected = onPersonSelected,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(clockHeight)
                                    .padding(horizontal = 28.dp, vertical = 20.dp),
                            )
                        }
                        IconGrid(
                            apps = pages.getOrElse(page) { emptyList() },
                            columns = columns,
                            cellHeight = cellHeight,
                            iconSize = iconDp,
                            shape = shape,
                            showLabels = showLabels,
                            drag = drag,
                            onOpen = onOpen,
                            onRemove = onRemoveFromHome,
                            onInfo = onInfo,
                            onUninstall = onUninstall,
                            onDrop = { finishDrag() },
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                ) {
                    repeat(pageCount) { i ->
                        val selected = i == pagerState.currentPage
                        Box(
                            Modifier
                                .size(if (selected) 7.dp else 6.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = if (selected) 1f else 0.45f)),
                        )
                    }
                }
            }

            // Dock
            Box(
                modifier = Modifier
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .onGloballyPositioned { drag.dockRect = it.boundsInRoot() }
                        .clip(RoundedCornerShape(32.dp))
                        .background(Color.White.copy(alpha = settings.dockAlpha))
                        .padding(horizontal = 6.dp, vertical = 10.dp),
                ) {
                    dockApps.take(DOCK_SLOTS).forEach { app ->
                        key(app.key) {
                            AppIcon(
                                app = app,
                                showLabel = false,
                                onClick = { onOpen(app) },
                                menu = listOf(
                                    MenuAction("Quitar del dock") { onRemoveFromDock(app) },
                                    MenuAction("Info de la app") { onInfo(app) },
                                    MenuAction("Desinstalar") { onUninstall(app) },
                                ),
                                modifier = Modifier.weight(1f),
                                iconSize = iconDp,
                                shape = shape,
                                drag = drag,
                                slotId = "d:" + app.key,
                                source = DragSource.DOCK,
                                onDrop = { finishDrag() },
                            )
                        }
                    }
                    repeat(DOCK_SLOTS - dockApps.size.coerceAtMost(DOCK_SLOTS)) {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }

        // Papelera + icono flotante mientras se arrastra
        val dragged = drag.app
        if (dragged != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 14.dp)
                    .onGloballyPositioned { drag.trashRect = it.boundsInRoot().inflate(28f) }
                    .clip(RoundedCornerShape(32.dp))
                    .background(if (drag.overTrash) Color(0xFFE53935) else Color.Black.copy(alpha = 0.6f))
                    .padding(horizontal = 22.dp, vertical = 14.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = null,
                        tint = Color.White,
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(text = "Quitar", color = Color.White, fontSize = 15.sp)
                }
            }

            val floatSize = iconDp * 1.15f
            val floatPx = with(density) { floatSize.toPx() }
            Image(
                bitmap = dragged.icon,
                contentDescription = null,
                modifier = Modifier
                    .offset {
                        IntOffset(
                            (drag.pointer.x - origin.x - floatPx / 2f).roundToInt(),
                            (drag.pointer.y - origin.y - floatPx / 2f).roundToInt(),
                        )
                    }
                    .size(floatSize)
                    .clip(shape),
            )
        }
    }
}

@Composable
private fun IconGrid(
    apps: List<AppInfo>,
    columns: Int,
    cellHeight: Dp,
    iconSize: Dp,
    shape: Shape,
    showLabels: Boolean,
    drag: DragController,
    onOpen: (AppInfo) -> Unit,
    onRemove: (AppInfo) -> Unit,
    onInfo: (AppInfo) -> Unit,
    onUninstall: (AppInfo) -> Unit,
    onDrop: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp),
    ) {
        apps.chunked(columns).forEach { row ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(cellHeight),
            ) {
                row.forEach { app ->
                    key(app.key) {
                        AppIcon(
                            app = app,
                            showLabel = showLabels,
                            onClick = { onOpen(app) },
                            menu = listOf(
                                MenuAction("Quitar de inicio") { onRemove(app) },
                                MenuAction("Info de la app") { onInfo(app) },
                                MenuAction("Desinstalar") { onUninstall(app) },
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                            iconSize = iconSize,
                            shape = shape,
                            drag = drag,
                            slotId = "h:" + app.key,
                            source = DragSource.HOME,
                            onDrop = onDrop,
                        )
                    }
                }
                repeat(columns - row.size) {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}
