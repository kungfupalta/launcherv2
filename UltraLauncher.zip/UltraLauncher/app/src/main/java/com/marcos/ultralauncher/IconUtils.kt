package com.marcos.ultralauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable

/**
 * Convierte el icono de una app en un bitmap cuadrado listo para recortarse con forma "squircle".
 * - Iconos adaptativos: se dibujan fondo + primer plano sin la máscara del sistema.
 * - Iconos antiguos: se centran sobre una placa clara (como hace One UI).
 */
fun Drawable.toIconBitmap(sizePx: Int): Bitmap {
    val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    val adaptive = this as? AdaptiveIconDrawable
    if (adaptive != null) {
        // La capa mide 108dp y la zona visible son los 72dp centrales.
        val offset = (sizePx * 18f / 72f).toInt()
        val left = -offset
        val top = -offset
        val right = sizePx + offset
        val bottom = sizePx + offset
        adaptive.background?.let {
            it.setBounds(left, top, right, bottom)
            it.draw(canvas)
        }
        adaptive.foreground?.let {
            it.setBounds(left, top, right, bottom)
            it.draw(canvas)
        }
    } else {
        canvas.drawColor(0xFFF1F1F1.toInt())
        val inset = (sizePx * 0.17f).toInt()
        setBounds(inset, inset, sizePx - inset, sizePx - inset)
        draw(canvas)
    }
    return bmp
}
