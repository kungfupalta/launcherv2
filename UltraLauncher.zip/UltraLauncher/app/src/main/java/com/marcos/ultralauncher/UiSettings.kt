package com.marcos.ultralauncher

enum class IconShapeOption(val id: String, val label: String) {
    SQUIRCLE("squircle", "Squircle"),
    CIRCLE("circle", "Círculo"),
    ROUNDED("rounded", "Suave"),
    SQUARE("square", "Cuadrado");

    companion object {
        fun fromId(id: String?): IconShapeOption =
            entries.firstOrNull { it.id == id } ?: SQUIRCLE
    }
}

/** Todo lo que se puede personalizar desde "Personalizar". */
data class UiSettings(
    val columns: Int = 4,
    val drawerColumns: Int = 4,
    val iconDp: Float = 56f,
    val showLabels: Boolean = true,
    val showClock: Boolean = true,
    val shape: IconShapeOption = IconShapeOption.SQUIRCLE,
    val dockAlpha: Float = 0.16f,
)
