package com.marcos.ultralauncher

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Collator
import java.util.Locale

data class AppInfo(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: ImageBitmap,
) {
    val key: String get() = "$packageName/$activityName"
}

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("ultra_launcher", Context.MODE_PRIVATE)
    private val pm: PackageManager = application.packageManager

    /** Todas las apps instaladas (cajón de apps), ordenadas alfabéticamente. */
    var apps by mutableStateOf<List<AppInfo>>(emptyList())
        private set

    /** Apps fijadas en la pantalla de inicio (en orden). */
    val homeKeys = mutableStateListOf<String>()

    /** Apps fijadas en el dock (máx. 4). */
    val dockKeys = mutableStateListOf<String>()

    /** Qué hora se muestra debajo del reloj: la de Marcos o la de Arianna. */
    var clockPerson by mutableStateOf(ClockPerson.fromId(prefs.getString(KEY_PERSON, null)))
        private set

    /** Ajustes de personalización (tamaño, columnas, forma de iconos...). */
    var settings by mutableStateOf(loadSettings())
        private set

    /** Sube cada vez que se pulsa "Inicio" estando ya en el launcher. */
    var homeSignal by mutableIntStateOf(0)
        private set

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            reloadApps()
        }
    }

    init {
        homeKeys.addAll(readList(KEY_HOME))
        dockKeys.addAll(readList(KEY_DOCK))

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(
            application,
            packageReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        reloadApps()
    }

    override fun onCleared() {
        try {
            getApplication<Application>().unregisterReceiver(packageReceiver)
        } catch (e: Exception) {
        }
        super.onCleared()
    }

    fun requestHome() {
        homeSignal++
    }

    fun selectPerson(person: ClockPerson) {
        clockPerson = person
        prefs.edit().putString(KEY_PERSON, person.id).apply()
    }

    fun addToHome(app: AppInfo) {
        if (app.key in homeKeys) {
            toast("Ya está en inicio")
            return
        }
        homeKeys.add(app.key)
        persist()
        toast("Añadida a inicio")
    }

    fun removeFromHome(app: AppInfo) {
        homeKeys.remove(app.key)
        persist()
    }

    fun addToDock(app: AppInfo) {
        if (app.key in dockKeys) {
            toast("Ya está en el dock")
            return
        }
        if (dockKeys.size >= DOCK_SIZE) {
            toast("El dock está lleno (máx. $DOCK_SIZE)")
            return
        }
        dockKeys.add(app.key)
        persist()
        toast("Añadida al dock")
    }

    fun removeFromDock(app: AppInfo) {
        dockKeys.remove(app.key)
        persist()
    }

    fun updateSettings(new: UiSettings) {
        settings = new
        prefs.edit()
            .putInt(KEY_COLUMNS, new.columns)
            .putInt(KEY_DRAWER_COLUMNS, new.drawerColumns)
            .putFloat(KEY_ICON_DP, new.iconDp)
            .putBoolean(KEY_LABELS, new.showLabels)
            .putBoolean(KEY_CLOCK, new.showClock)
            .putString(KEY_SHAPE, new.shape.id)
            .putFloat(KEY_DOCK_ALPHA, new.dockAlpha)
            .apply()
    }

    private fun loadSettings(): UiSettings = UiSettings(
        columns = prefs.getInt(KEY_COLUMNS, 4).coerceIn(4, 6),
        drawerColumns = prefs.getInt(KEY_DRAWER_COLUMNS, 4).coerceIn(4, 6),
        iconDp = prefs.getFloat(KEY_ICON_DP, 56f).coerceIn(40f, 80f),
        showLabels = prefs.getBoolean(KEY_LABELS, true),
        showClock = prefs.getBoolean(KEY_CLOCK, true),
        shape = IconShapeOption.fromId(prefs.getString(KEY_SHAPE, null)),
        dockAlpha = prefs.getFloat(KEY_DOCK_ALPHA, 0.16f).coerceIn(0f, 0.6f),
    )

    /** Mueve [from] a la posición de [to] dentro del inicio. */
    fun moveHome(from: String, to: String) {
        val i = homeKeys.indexOf(from)
        val j = homeKeys.indexOf(to)
        if (i < 0 || j < 0 || i == j) return
        homeKeys.removeAt(i)
        homeKeys.add(j, from)
        persist()
    }

    /** Mueve [from] a la posición de [to] dentro del dock. */
    fun moveDock(from: String, to: String) {
        val i = dockKeys.indexOf(from)
        val j = dockKeys.indexOf(to)
        if (i < 0 || j < 0 || i == j) return
        dockKeys.removeAt(i)
        dockKeys.add(j, from)
        persist()
    }

    /** Del inicio al dock. Si el dock está lleno y se suelta sobre un icono, se intercambian. */
    fun homeToDock(key: String, before: String?) {
        val i = homeKeys.indexOf(key)
        if (i < 0 || key in dockKeys) return
        val j = if (before != null) dockKeys.indexOf(before) else -1
        if (dockKeys.size >= DOCK_SIZE) {
            if (j < 0) {
                toast("El dock está lleno (máx. $DOCK_SIZE)")
                return
            }
            val old = dockKeys[j]
            dockKeys[j] = key
            homeKeys[i] = old
        } else {
            if (j >= 0) dockKeys.add(j, key) else dockKeys.add(key)
            homeKeys.removeAt(i)
        }
        persist()
    }

    /** Del dock al inicio (antes de [before], o al final). */
    fun dockToHome(key: String, before: String?) {
        val i = dockKeys.indexOf(key)
        if (i < 0 || key in homeKeys) return
        dockKeys.removeAt(i)
        val j = if (before != null) homeKeys.indexOf(before) else -1
        if (j >= 0) homeKeys.add(j, key) else homeKeys.add(key)
        persist()
    }

    fun reloadApps() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.Default) { queryApps() }
            apps = list
            if (!prefs.getBoolean(KEY_SEEDED, false) && list.isNotEmpty()) {
                seedDefaults(list)
            }
        }
    }

    private fun queryApps(): List<AppInfo> {
        val ctx = getApplication<Application>()
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(intent, 0)
        val iconPx = (ctx.resources.displayMetrics.density * 64f).toInt().coerceAtLeast(96)
        val collator = Collator.getInstance(Locale.getDefault())
        return resolved
            .filter { it.activityInfo.packageName != ctx.packageName }
            .mapNotNull { ri ->
                try {
                    val ai = ri.activityInfo
                    AppInfo(
                        label = ri.loadLabel(pm).toString(),
                        packageName = ai.packageName,
                        activityName = ai.name,
                        icon = ri.loadIcon(pm).toIconBitmap(iconPx).asImageBitmap(),
                    )
                } catch (e: Exception) {
                    null
                }
            }
            .sortedWith { a, b -> collator.compare(a.label, b.label) }
    }

    /** Primera vez: rellena el dock y el inicio con las apps típicas de un teléfono. */
    private fun seedDefaults(list: List<AppInfo>) {
        val byPackage = list.groupBy { it.packageName }

        fun firstFor(intent: Intent): AppInfo? {
            val packages = pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
                .map { it.activityInfo.packageName }
            for (p in packages) {
                val found = byPackage[p]?.firstOrNull()
                if (found != null) return found
            }
            return null
        }

        val dock = listOfNotNull(
            firstFor(Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))),
            firstFor(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"))),
            firstFor(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example.com"))),
            firstFor(Intent(MediaStore.ACTION_IMAGE_CAPTURE)),
        ).distinctBy { it.key }

        val galleryIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse("content://media/external/images/media/1"), "image/*")
        }
        val fromIntents = listOfNotNull(
            firstFor(galleryIntent),
            firstFor(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)),
            firstFor(Intent(AlarmClock.ACTION_SHOW_ALARMS)),
            firstFor(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR)),
            firstFor(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR)),
            firstFor(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_EMAIL)),
            firstFor(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MAPS)),
            firstFor(Intent(Settings.ACTION_SETTINGS)),
        )
        val fromPackages = listOf(
            "com.android.vending",
            "com.google.android.youtube",
            "com.google.android.apps.photos",
            "com.google.android.gm",
            "com.whatsapp",
            "com.instagram.android",
            "com.spotify.music",
        ).mapNotNull { byPackage[it]?.firstOrNull() }

        val dockKeysSet = dock.map { it.key }.toSet()
        val home = (fromIntents + fromPackages)
            .distinctBy { it.key }
            .filter { it.key !in dockKeysSet }

        dockKeys.clear()
        dockKeys.addAll(dock.map { it.key })
        homeKeys.clear()
        homeKeys.addAll(home.map { it.key })
        persist()
        prefs.edit().putBoolean(KEY_SEEDED, true).apply()
    }

    private fun readList(key: String): List<String> =
        (prefs.getString(key, "") ?: "").split("\n").filter { it.isNotBlank() }

    private fun persist() {
        prefs.edit()
            .putString(KEY_HOME, homeKeys.joinToString("\n"))
            .putString(KEY_DOCK, dockKeys.joinToString("\n"))
            .apply()
    }

    private fun toast(text: String) {
        Toast.makeText(getApplication<Application>(), text, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        const val KEY_HOME = "home_keys"
        const val KEY_DOCK = "dock_keys"
        const val KEY_PERSON = "clock_person"
        const val KEY_SEEDED = "seeded"
        const val KEY_COLUMNS = "ui_columns"
        const val KEY_DRAWER_COLUMNS = "ui_drawer_columns"
        const val KEY_ICON_DP = "ui_icon_dp"
        const val KEY_LABELS = "ui_labels"
        const val KEY_CLOCK = "ui_clock"
        const val KEY_SHAPE = "ui_shape"
        const val KEY_DOCK_ALPHA = "ui_dock_alpha"
        const val DOCK_SIZE = 4
    }
}
